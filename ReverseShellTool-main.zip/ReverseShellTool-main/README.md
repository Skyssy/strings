# ReverseShellTool

Après avoir téléchargé le fichier, il vous suffit d'ouvrir vos ports, puis de changer l'hôte et le port dans les fichiers à votre ip et votre port ouvert et vous devez simplement envoyer le fichier "victim.pyw" à la victime.
Une fois qu'ils l'auront téléchargé et éxécuté, vous aurez un accès complet à leur invite de commandes.

# Disclaimer
JE NE SUIS PAS RESPONSABLE DE VOS ACTIONS AVEC MON TOOL, VEUILLEZ L'UTILISER UNIQUEMENT À DES FINS ÉDUCATIVES
